/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package carsharing;

import cl.duoc.models.Auto;
import cl.duoc.models.BicicletaElectrica;
import cl.duoc.models.Moto;
import cl.duoc.models.RegistroFlota;

/**
 *
 * @author Cetecom
 */
public class Carsharing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Auto auto1 = new Auto(3, true, "PWLP23", true, "Auto", 6);
        Auto auto2 = new Auto(4, false, "HODE42", true, "Auto", 3);
        Auto auto3 = new Auto(4, false, "WEED69", false, "Auto", 23);
        Moto moto1 = new Moto(20, true, 7, "VPK45", true, "Moto", 11);
        Moto moto2 = new Moto(40, false, 0, "GLU22", false, "Moto", 7);
        BicicletaElectrica bici1 = new BicicletaElectrica("Hidraulicos", 19, "NFK32", true, 
                "Bicicleta electrica", 10);
        BicicletaElectrica bici2 = new BicicletaElectrica("Hidraulicos", 21, "KFDS89", true, 
                "Bicicleta electrica", 18);
        RegistroFlota registro = new RegistroFlota();
        
        /*
        Double valor = auto1.costoValorTotal();
        auto1.mostrarDatos();
        System.out.println(valor.floatValue());
        
        Double valor2 = moto1.costoValorTotal();
        moto1.mostrarDatos();
        System.out.println(valor2.floatValue());
        
        Double valor3 = bici1.costoValorTotal();
        bici1.mostrarDatos();
        System.out.println(valor3.floatValue());
        */
        
        registro.validarIdVehiculo(auto1);
        registro.validarIdVehiculo(auto2);
        registro.validarIdVehiculo(auto3);
        registro.validarIdVehiculo(moto1);
        registro.validarIdVehiculo(moto2);
        registro.validarIdVehiculo(bici1);
        registro.validarIdVehiculo(bici2);
        registro.listarVehiculos();
        registro.cantidadVehiculos();
        double valor = registro.calculoTotalAlquiler();
        System.out.println("El valor total de los vehiculos de la flota es de: " + valor);
        
     
    }
    
}
