/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duoc.models;

/**
 *
 * @author Cetecom
 */
public class BicicletaElectrica extends Vehiculo {
    
    private String tipofrenos;
    private int capacidadbateriakm;

    public BicicletaElectrica(String idvehiculo, boolean mantenimiento, String tipo, int horasusadas) {
        super(idvehiculo, mantenimiento, tipo, horasusadas);
    }
    
    

    public BicicletaElectrica(String tipofrenos, int capacidadbateriakm, String idvehiculo, boolean mantenimiento, String tipo, int horasusadas) {
        super(idvehiculo, mantenimiento, tipo, horasusadas);
        this.tipofrenos = tipofrenos;
        this.capacidadbateriakm = capacidadbateriakm;
    }

    public String getTipofrenos() {
        return tipofrenos;
    }

    public void setTipofrenos(String tipofrenos) {
        this.tipofrenos = tipofrenos;
    }

    public int getCapacidadbateriakm() {
        return capacidadbateriakm;
    }

    public void setCapacidadbateriakm(int capacidadbateriakm) {
        this.capacidadbateriakm = capacidadbateriakm;
    }

    @Override
    public String toString() {
        return "BicicletaElectrica{" + "tipofrenos=" + tipofrenos + ", capacidadbateriakm=" + capacidadbateriakm + '}';
    }
    
    @Override
     public double costoValorTotal() {
         double costo = VALOR_HORA_ALQUILER * horasusadas;
         if (capacidadbateriakm < 20) {
             costo *= 0.95;
         }
         return costo;
     }
    
      @Override
     public void mostrarDatos() {
         System.out.println("--------------" + getTipo() + "--------------");
         System.out.println("ID: " + getIdvehiculo() + "\nNecesitar mantenimiento: " + isMantenimiento() + "\nTipo vehiculo: " + getTipo()
         + "\nHoras de uso: " + getHorasusadas() + "\nCapacidad de la bateria en KM: " + getCapacidadbateriakm() + 
                 "\nTipo de frenos: " + getTipofrenos() + "\nCosto alquiler: " + costoValorTotal());
         System.out.println("================================");
         System.out.println(" ");
    }
}
