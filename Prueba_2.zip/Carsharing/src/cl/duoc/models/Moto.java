/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duoc.models;

/**
 *
 * @author Cetecom
 */
public class Moto extends Vehiculo{
    
    private int capacidadbateria;
    private boolean asistenciaeco;
    private int tiempomodoeco;

    public Moto(String idvehiculo, boolean mantenimiento, String tipo, int horasusadas) {
        super(idvehiculo, mantenimiento, tipo, horasusadas);
    }



    public Moto(int capacidadbateria, boolean asistenciaeco, int tiempomodoeco, String idvehiculo, boolean mantenimiento, String tipo, int horasusadas) {
        super(idvehiculo, mantenimiento, tipo, horasusadas);
        this.capacidadbateria = capacidadbateria;
        this.asistenciaeco = asistenciaeco;
        this.tiempomodoeco = tiempomodoeco;
    }

    public int getCapacidadbateria() {
        return capacidadbateria;
    }

    public void setCapacidadbateria(int capacidadbateria) {
        this.capacidadbateria = capacidadbateria;
    }

    public boolean isAsistenciaeco() {
        return asistenciaeco;
    }

    public void setAsistenciaeco(boolean asistenciaeco) {
        this.asistenciaeco = asistenciaeco;
    }
    
    public int getTiempomodoeco() {
        return tiempomodoeco;
    }
    
    public void setTiempomodoeco(int tiempomodoeco) {
        this.tiempomodoeco = tiempomodoeco;
    }

    @Override
    public String toString() {
        return "Moto{" + "capacidadbateria=" + capacidadbateria + ", asistenciaeco=" + asistenciaeco + ", tiempomodoeco=" + tiempomodoeco + '}';
    }
    
    @Override
     public double costoValorTotal() {
         double costo = VALOR_HORA_ALQUILER * horasusadas;
         double mitadviaje = horasusadas / 2;
         if (asistenciaeco == true && tiempomodoeco > mitadviaje) {
             costo *= 1.08;
         }
         return costo;
     }
    
        @Override
     public void mostrarDatos() {
         System.out.println("--------------" + getTipo() + "--------------");
         System.out.println("ID: " + getIdvehiculo() + "\nNecesitar mantenimiento: " + isMantenimiento() + "\nTipo vehiculo: " + getTipo()
         + "\nHoras de uso: " + getHorasusadas() + "\nCapacidad de bateria: " + 
                 getCapacidadbateria() + "\nAsistencia en modo eco: " + isAsistenciaeco() + 
                 "\nTiempo en modo eco: " + getTiempomodoeco() + "\nCosto alquiler: " + costoValorTotal());
         System.out.println("================================");
         System.out.println(" ");
    }
    
    
}
