/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duoc.models;

/**
 *
 * @author Cetecom
 */
public class Auto extends Vehiculo {
    
    private int cantidadpasajeros;
    private boolean autopiloto;

    public Auto(String idvehiculo, boolean mantenimiento, String tipo, int horasusadas) {
        super(idvehiculo, mantenimiento, tipo, horasusadas);
    }
    
    

    public Auto(int cantidadpasajeros, boolean autopiloto, String idvehiculo, boolean mantenimiento, String tipo, int horasusadas) {
        super(idvehiculo, mantenimiento, tipo, horasusadas);
        this.cantidadpasajeros = cantidadpasajeros;
        this.autopiloto = autopiloto;
    }

    

    public int getCantidadpasajeros() {
        return cantidadpasajeros;
    }

    public void setCantidadpasajeros(int cantidadpasajeros) {
        this.cantidadpasajeros = cantidadpasajeros;
    }

    public boolean isAutopiloto() {
        return autopiloto;
    }

    public void setAutopiloto(boolean autopiloto) {
        this.autopiloto = autopiloto;
    }

    @Override
    public String toString() {
        return "Auto{" + "cantidadpasajeros=" + cantidadpasajeros + ", autopiloto=" + autopiloto + '}';
    }

    @Override
     public double costoValorTotal() {
         double costo = VALOR_HORA_ALQUILER * horasusadas;
         if (autopiloto == true) {
             costo *= 1.10;
         }
         return costo;
     }
     
     @Override
     public void mostrarDatos() {
         System.out.println("--------------" + getTipo() + "--------------");
         System.out.println("ID: " + getIdvehiculo() + "\nNecesitar mantenimiento: " + isMantenimiento() + "\nTipo vehiculo: " + getTipo()
         + "\nHoras de uso: " + getHorasusadas() + "\nCantidad de pasajeros: " + getCantidadpasajeros() + 
                 "\nAutopiloto: " + isAutopiloto() + "\nCosto alquiler: " + costoValorTotal());
         System.out.println("================================");
         System.out.println(" ");
    }

}
