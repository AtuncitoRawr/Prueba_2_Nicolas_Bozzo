/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duoc.models;

/**
 *
 * @author Cetecom
 */
public abstract class Vehiculo implements ivalorvehiculo {
    
    public final String idvehiculo;
    public boolean mantenimiento;
    public String tipo;
    public int horasusadas;

    public Vehiculo(String idvehiculo, boolean mantenimiento, String tipo, int horasusadas) {
        this.idvehiculo = idvehiculo;
        this.mantenimiento = mantenimiento;
        this.tipo = tipo;
        this.horasusadas = horasusadas;
    }
    
    public String getIdvehiculo() {
        return idvehiculo;
    }

    public boolean isMantenimiento() {
        return mantenimiento;
    }

    public void setMantenimiento(boolean mantenimiento) {
        this.mantenimiento = mantenimiento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getHorasusadas() {
        return horasusadas;
    }

    public void setHorasusadas(int horasusadas) {
        this.horasusadas = horasusadas;
    }
    
    @Override
    public abstract String toString();
    
    @Override
    public abstract double costoValorTotal();
 
    public void mostrarDatos(){
    }
    
    
    
}
