/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duoc.models;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Cetecom
 */
public class RegistroFlota {
    
    private List<Vehiculo> idvehiculos = new ArrayList<>();
    private List<Vehiculo> Vehiculos = new ArrayList<>();

    public RegistroFlota() {
    }

    public List<Vehiculo> getIdvehiculos() {
        return idvehiculos;
    }

    public void setIdvehiculos(List<Vehiculo> idvehiculos) {
        this.idvehiculos = idvehiculos;
    }

    public List<Vehiculo> getVehiculos() {
        return Vehiculos;
    }

    public void setVehiculos(List<Vehiculo> Vehiculos) {
        this.Vehiculos = Vehiculos;
    }

    @Override
    public String toString() {
        return "RegistroFlota{" + "idvehiculos=" + idvehiculos + ", Vehiculos=" + Vehiculos + '}';
    }
    
    

    
   
    public void validarIdVehiculo (Vehiculo veh) {
         
        if (idvehiculos.contains(veh)) {
            
  
            System.out.println("ERROR, ese vehiculo ya esta en el registro");
        } else {
            idvehiculos.add(veh);
            Vehiculos.add(veh);
        }
    }

    
    public void listarVehiculos() {
        for (Vehiculo i: Vehiculos) {
            i.mostrarDatos();
        }
    }
    
    public void cantidadVehiculos() {
        System.out.println("El numero de vehiculos en la flota es de: " + Vehiculos.size());
    }
    
    public double calculoTotalAlquiler() {
        double valor = 0;
        for (Vehiculo i : Vehiculos) {
           valor += i.costoValorTotal();
        }
        return valor;
    }
    
}
